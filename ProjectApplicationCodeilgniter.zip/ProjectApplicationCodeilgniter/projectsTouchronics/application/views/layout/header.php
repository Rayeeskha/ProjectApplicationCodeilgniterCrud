<!DOCTYPE html>
<html>
<head>
	<title>Blog</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/bootstrap.min.css') ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/bootstrap-theme.min.css') ?>">

	<script type="text/javascript" src="<?php echo base_url('assets/js/jquery-ui.js') ?>"></script>

	<link rel="stylesheet" type="text/css" href="//cdn.datatables.net/plug-ins/3cfcc339e89/integration/bootstrap/3/dataTables.bootstrap.css">

	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap">

	<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/styles.min.css'); ?>">

	<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/jquery-3.1.1.min.js"></script>
	<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/bootstrap.min.js"></script>

	<script language="JavaScript" src="https://cdn.datatables.net/1.10.4/js/jquery.dataTables.min.js" type="text/javascript"></script>
<script language="JavaScript" src="https://cdn.datatables.net/plug-ins/3cfcc339e89/integration/bootstrap/3/dataTables.bootstrap.js" type="text/javascript"></script>




<style type="text/css">
	* {
	margin: 0;
	padding: 0;
	border: 0;
}
body {
	background: #F2F4F8;
	font-family: "Avenir Next W01","Proxima Nova W01","Rubik",-apple-system,system-ui,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif;
    font-size: 14px;
    line-height: 1.5;
    color: #3E4B5B;
    text-align: left;
}

</style>


</head>
<body>

<div class="navbar navbar-default">
	<div class="container">
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<aside class="col-md-2 col-lg-2 col-sm-2 col-xs-3 ">

		<a href="#"><img src="assets/images/touchcronics.png" class="logoImg img-responsive"/></a>
	</aside>
	</div>
</div>
<div class="container">